# Dementor Live · NEW-ONLY v3.1 · QA 2026-10-20

## Installed scope
- 42 new standalone SVGs: `DL-ICON-021`…`DL-ICON-062`, each 2–4 paper forms, exactly approved muted palette, no SVG scripts/filter/images/gradients.
- 210 derived PNG at 32/48/64/128/256 px with transparent corners; each SHA-256 matched manifest.
- Old 20 v2 source, sprites, JS and CSS intentionally **not packaged for write**. Installer pre/post checksums old `public/assets/paper-icons` and `public/paper-icons.js`/CSS.
- Only 8 playable new item types receive optional DOM decoration: shovel, 5 tree seeds, pistol, pager. Cave/fishing art staged until feature connects; world/concept icons only previews.

## Automated checks and evidence
| Test | Result |
|---|---|
| 42 SVG unique stable number + ID | PASS |
| SVG exact 2–4 path/circle/rect/ellipse/polyline/polygon + palette | PASS |
| 210 PNG image size, alpha corners, content and SHA-256 | PASS |
| `node --check new-icons-v3.js` | PASS |
| Synthetic runtime install | PASS |
| Every approved v2 file SHA-256 unchanged | PASS |
| Installation run twice byte-for-byte idempotent | PASS |
| Invalid server layout rejected without proceeding | PASS |
| Chromium DOM check of shovel, forest seeds, pager, pistol | PASS; 6 correct additions, no JS exceptions |
| Chromium HTTP verification of PNG load | NOT RUN / ERR_BLOCKED_BY_ADMINISTRATOR for localhost |
| Real Mac CIVIC runtime with actual saved world | NOT RUN |
| iPhone Safari / two-player gameplay regression | NOT RUN |
| Artistic sign-off for all 42 new SVGs | PENDING |

## Safety
No old v2 icons overwritten, no hero changes, no game-state keys or save migration, no economy mutation. The archive installer updates only static asset access and supplemental browser decorations in local runtime, never production automatically. Production release requires checks against exact runtime SHA, safe backup and rollback. Don't run `--reset-world`.
