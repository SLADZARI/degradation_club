from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
HTML='''<!doctype html><html lang="ru"><head><meta charset="utf-8"></head><body><div id="cityPanel" data-mode="seeds"><div id="cityPanelRows"><section class="city-row"><h3>🫘 Семена ели</h3></section><section class="city-row"><h3>Лопата · 18 использований</h3></section><section class="city-row"><h3>Жёлудь дуба</h3></section></div></div><button id="bag-item-seed_tree_oak"><span>·</span>1</button><div id="quickbar"><button class="quick-slot"><span>·</span></button></div><button id="openPager">▣ Пейджер</button><div id="weaponStatus">Пистолет · 8 в магазине</div><button id="switchWeapon"><span class="action-caption">Пистолет → автомат</span></button></body></html>'''
with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':450,'height':700})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('about:blank')
  page.set_content(HTML,wait_until='load')
  page.add_script_tag(content="let quickSlots=['seed_tree_spruce'];")
  page.add_script_tag(path=str(ROOT/'new-icons-v3.js'))
  page.wait_for_timeout(250)
  ids=page.locator('img.paper-new-v3').evaluate_all('(nodes)=>nodes.map(n=>n.dataset.newIcon)')
  assert all(i in ids for i in ('seed_tree_spruce','seed_tree_oak','shovel','pager','pistol')),ids
  assert len(ids)==8,ids
  assert not errors,errors
  assert page.locator('h3').first.inner_text().startswith('Семена ели')
  print('BROWSER DOM PASS',ids,'js errors',len(errors),'image HTTP NOT TESTED (browser local access blocked)')
  page.screenshot(path=str(ROOT/'QA_RUNTIME_NEW_ONLY.png'),full_page=True)
  browser.close()
