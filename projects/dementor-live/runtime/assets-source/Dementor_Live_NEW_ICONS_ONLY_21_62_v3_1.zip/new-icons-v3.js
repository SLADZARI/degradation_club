/* Dementor Live supplemental Paper Cut icons v3, DL-ICON-021..062 ONLY.
   Non-invasive: old approved v2 icon assets and their runtime API are untouched.
   New UI highlights: shovel, 5 forest seeds, pistol, pager. Others are catalog-only.
*/
(()=>{'use strict';
const assets={
 'shovel':['DL-ICON-021','Лопата'],
 'seed_tree_broadleaf':['DL-ICON-022','Лиственное'],
 'seed_tree_round':['DL-ICON-023','Круглая крона'],
 'seed_tree_oak':['DL-ICON-024','Дуб'],
 'seed_tree_spruce':['DL-ICON-025','Ель'],
 'seed_tree_small':['DL-ICON-026','Маленькое дерево'],
 'pistol':['DL-ICON-027','Пистолет'],
 'pager':['DL-ICON-028','Пейджер']};
const reg=window.DementorNewPaperIcons={version:'3.1.0-new-only',assets:Object.freeze(assets),src:(id,size=64)=>{
 if(!assets[id]||![32,48,64,128,256].includes(size))return null;
 return '/assets/paper-icons-new-v3/png_'+size+'/'+id+'.png';
},allAssets:()=>'/assets/paper-icons-new-v3/manifest-new-only.json'};
function badge(parent,id){
 if(!parent||!assets[id])return;
 if(parent.querySelector(':scope > img.paper-new-v3[data-new-icon="'+id+'"]'))return;
 // Wrong legacy carrot emoji was shown beside *new tree* species; remove only there.
 if(id.startsWith('seed_tree_')){
   for(const n of [...parent.childNodes]){
     if(n.nodeType===1&&n.matches?.('img.paper-icon')&&(/seed_carrot/).test(n.getAttribute('src')||''))n.remove();
     if(n.nodeType===3&&/^[\s]*[🫘🌰]/u.test(n.nodeValue||''))n.nodeValue=n.nodeValue.replace(/^[\s]*[🫘🌰]+\s*/u,'');
   }
 }
 const img=document.createElement('img');img.className='paper-new-v3';img.dataset.newIcon=id;
 img.src=reg.src(id,64);img.alt='';img.setAttribute('aria-hidden','true');img.width=28;img.height=28;img.draggable=false;
 parent.prepend(img);
}
const findSeed=(text)=>{
 const s=text.replace(/^[\s🫘🌰]+/gu,'').toLowerCase();
 if(/широколист|лиственн/.test(s))return 'seed_tree_broadleaf';
 if(/кругл|шаровид/.test(s))return 'seed_tree_round';
 if(/жёлуд|желуд|\bдуб/.test(s))return 'seed_tree_oak';
 if(/ел[ьи]|елк|ёлк/.test(s))return 'seed_tree_spruce';
 if(/мал(еньк|ое|ого).*дерев|карлик/.test(s))return 'seed_tree_small';
 return null;
};
function render(){
 // Forest seed icons in existing bag cells. Never overwrite approved v2 files.
 for(const tile of document.querySelectorAll('[id^="bag-item-seed_tree_"]')){
   const item=tile.id.slice('bag-item-'.length);
   if(assets[item]){badge(tile,item);const old=tile.querySelector(':scope > span');if(old)old.hidden=true;}
 }
 // Existing quickbar UI: decorate only new forestry seed items, no state mutation.
 try{
   if(typeof quickSlots!=='undefined'&&Array.isArray(quickSlots)){
     document.querySelectorAll('#quickbar .quick-slot').forEach((slot,i)=>{
       const item=quickSlots[i];if(!assets[item]||!item.startsWith('seed_tree_'))return;
       badge(slot,item);const old=slot.querySelector(':scope > span');if(old)old.hidden=true;
     });
   }
 }catch{} // Other builds need not expose quickSlots.
 const seedsActive=document.querySelector('#cityPanel')?.dataset.mode==='seeds';
 // Update seed shop display, not the existing 20 item graphics.
 for(const title of document.querySelectorAll('#cityPanelRows .city-row h3')){
   const text=title.textContent||'';
   const id=(seedsActive?findSeed(text):null)||(/лопат/i.test(text)?'shovel':null);
   if(id)badge(title,id);
 }
 badge(document.querySelector('#openPager'),'pager');
 const status=document.querySelector('#weaponStatus');
 if(status&&/Пистолет/i.test(status.textContent||''))badge(status,'pistol');
 const switchButton=document.querySelector('#switchWeapon .action-caption');
 if(switchButton&&/Пистолет/i.test(switchButton.textContent||''))badge(switchButton,'pistol');
}
let queued=false;
function enqueue(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;render();});}
const sheet=document.createElement('style');sheet.textContent='img.paper-new-v3{display:inline-block!important;width:26px;height:26px;object-fit:contain;vertical-align:middle;margin-right:6px;flex:none}#openPager img.paper-new-v3{width:20px;height:20px;margin-right:4px}';document.head.append(sheet);
if(document.body){enqueue();new MutationObserver(enqueue).observe(document.body,{subtree:true,childList:true,characterData:true});}
})();
