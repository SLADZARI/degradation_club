/* Dementor Live | Paper Cut icons v1 | 20 canonical assets
 * The stylesheet and mappings affect UI only; world sprites and character are untouched.
 * Keys are stable gameplay IDs. UI-only concepts are kept separate from physical bag items.
 */
(() => {
  'use strict';
  const keys = ['wood','stone','food','seed_hemp','seed_carrot','hemp','carrot','water','axe','pick','rifle','ammo','map','shirt','souvenir','paper','backpack','cargo','health','stamina'];
  const aliases = { 'starter-rifle':'rifle', weapon:'rifle', ammunition:'ammo', seedHemp:'seed_hemp', seedCarrot:'seed_carrot', wallet:'paper', currency:'paper', tshirt:'shirt', souvenir:'souvenir', courier:'cargo' };
  const atlasUrl = '/assets/paper-icons/paper_atlas_64_indexed.png';
  const style = document.createElement('style');
  style.id = 'dementor-paper-icons-v1';
  style.textContent = `
  .paper-cut-icon {
    display:inline-block;box-sizing:border-box;flex:none;
    width:1.45em;height:1.45em;vertical-align:-.29em;
    background-image:url('${atlasUrl}');background-size:500% 400%;background-repeat:no-repeat;
    background-color:transparent;image-rendering:auto;pointer-events:none;
  }
  .paper-cut-icon--sm{width:1.08em;height:1.08em;vertical-align:-.19em}
  .paper-cut-icon--lg{width:1.9em;height:1.9em;vertical-align:-.45em}
  .quick-slot .paper-cut-icon,.slot .paper-cut-icon{width:1.5em;height:1.5em;vertical-align:middle}
  #bagButton .paper-cut-icon{width:1.7em;height:1.7em;vertical-align:middle}
  .city-row h3 .paper-cut-icon{margin-right:.28em}
  .battle-icon .paper-cut-icon{margin-right:.3em}
  `;
  document.head.append(style);
  function normalize(id) { const normalized=aliases[id]||id; return keys.includes(normalized)?normalized:null; }
  function icon(id,size='normal') {
    const key=normalize(id);if(!key)return null;
    const i=keys.indexOf(key),span=document.createElement('span');
    span.className='paper-cut-icon'+(size==='small'?' paper-cut-icon--sm':size==='large'?' paper-cut-icon--lg':'');
    span.style.backgroundPosition=`${(i%5)*25}% ${Math.floor(i/5)*100/3}%`;
    span.dataset.paperIcon=key;span.setAttribute('aria-hidden','true');
    return span;
  }
  function prepend(node,id,size='normal') {
    if(!node)return;const key=normalize(id);if(!key)return;
    if(node.firstElementChild?.dataset?.paperIcon===key)return;
    node.querySelectorAll(':scope > .paper-cut-icon').forEach(n=>n.remove());
    const el=icon(key,size);node.insertBefore(el,node.firstChild);
  }
  function replaceSymbol(selector,id,emoji) {
    const node=document.querySelector(selector);if(!node)return;
    for(const child of [...node.childNodes]){
      if(child.nodeType===Node.TEXT_NODE&&child.textContent.includes(emoji)){
        child.textContent=child.textContent.replace(emoji,'').replace(/^\s+/,'');break;
      }
      if(child.nodeType===Node.ELEMENT_NODE&&child.textContent.trim()===emoji){child.remove();break;}
    }
    prepend(node,id);
  }
  function mountCity() {
    replaceSymbol('#woodCount','wood','🪵');
    replaceSymbol('#stoneCount','stone','🪨');
    replaceSymbol('#eatButton','food','🫐');
    replaceSymbol('#bagButton','backpack','🎒');
    prepend(document.querySelector('#cargo'),'cargo','small');
    replaceSymbol('#axeButton span','axe','⚒');
    replaceSymbol('#pickButton span','pick','⛏');
    replaceSymbol('#mobileEatButton','food','🫐');
    for(const [selector,key] of [['label[for="health"]','health'],['label[for="hunger"]','food'],['label[for="stamina"]','stamina']]) prepend(document.querySelector(selector),key,'small');
  }
  function decorateCombat() {
    for(const [selector,key] of [['#inventory','rifle'],['#ammo','ammo'],['#health','health'],['#food','food']])prepend(document.querySelector(selector),key);
  }
  function watchLeading(node,key) {
    if(!node)return;
    const refresh=()=>{if(node.firstElementChild?.dataset?.paperIcon!==key)prepend(node,key)};
    refresh();
    const observer=new MutationObserver(refresh);
    observer.observe(node,{childList:true});
  }
  function mount(){
    mountCity();
    watchLeading(document.querySelector('#wallet'),'paper');
    for(const [sel,key] of [['#inventory','rifle'],['#ammo','ammo'],['#health','health'],['#food','food']]){
      if(document.querySelector('#battle'))watchLeading(document.querySelector(sel),key);
    }
  }
  const api=Object.freeze({keys:Object.freeze([...keys]),normalize,icon,prepend,mountCity,decorateCombat,version:'1.0.0'});
  window.PaperIcons=api;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
