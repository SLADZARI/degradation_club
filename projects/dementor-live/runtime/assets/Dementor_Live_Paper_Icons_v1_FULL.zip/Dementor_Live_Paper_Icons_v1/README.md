# DEMENTOR LIVE — Paper Cut Inventory Icons v1

**Status:** canonical visual assets of UI inventory / combat / travel, based on two approved artwork sheets from this conversation. The hero, environment art, UI layout, saves and gameplay are out of scope.

## Contents

- `icons_256/*.png` — 20 transparent 256×256 RGBA icon PNGs.
- `icons_64/*.png` — 20 64×64 RGBA thumbnails.
- `paper_atlas_64_indexed.png` — 5×4 sprite atlas at 64px per cell (320×256), compressed/paletted to reduce load; the actual 20 illustrations are the same approved graphics.
- `paper_atlas_128.png` — full-color larger atlas.
- `QA_contact_sheet.png` — preview on a checkerboard to reveal transparency defects.
- `icons_registry.json` — 20 ID mappings, sources and hashes for provenance.
- `runtime/public/paper-icons.js` — reusable front-end API `PaperIcons.icon(key)` and `PaperIcons.prepend(element,key)`.
- `install-paper-icons.mjs` — idempotent local integration. Patches only city HTML, combat HTML, `app.js`, world-ui script, and static assets.
- `preview.html` — 20 icons at real UI sizes on different backgrounds; open in a browser.

## Install in your current local Dementor Live copy

Requires Node.js 22+. Unzip this archive anywhere, then run:

```sh
node /path/to/Dementor_Live_Paper_Icons_v1/install-paper-icons.mjs /path/to/degradation_club/projects/dementor-live/runtime
```

From the game's runtime directory run `npm start`. Reload `http://127.0.0.1:4173/` in the browser. **Do not remove data/world.json.** An existing Node server requires restart for file changes to be served consistently.

Only this set of paper-cut icons is canonical for the listed UI items. The `paper` balance symbol is visual only. Ammo and weapon data reside in the combat profile, while shirt/map/souvenir are in `worldTravel`, not physical city-bag resources. No new item types are created.

## QA & limitations

The poster sources were opaque, so backgrounds were programmatically isolated with image segmentation and alpha matting. **Detailed edges are candidates for final human visual QA** (especially paper/map/seed clusters), even though the images have actual transparency. The atlas is compressed for fast UI use; the 256px originals are supplied separately.

The `install-paper-icons.mjs` patch has source-pattern checks and is idempotent. It has not been executed on the user's current Mac or production server by this package. Use the downloaded archive to apply it locally. The original generated artwork has not been redrawn.
