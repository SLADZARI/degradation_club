// Idempotent local installer for Dementor Live runtime (Node 22+).
// UI only: gameplay, save state, characters and world sprites are not touched.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const runtime=path.resolve(process.argv[2]||'.');
const pub=path.join(runtime,'public');
if(!fs.existsSync(path.join(pub,'app.js'))||!fs.existsSync(path.join(pub,'index.html'))){
 console.error('Expected Dementor Live runtime root with public/app.js and public/index.html');process.exit(2);
}
const modifications={};
function rewrite(name,rule){const p=path.join(pub,name);if(!fs.existsSync(p)){console.log('SKIP (not found): '+name);return;}let s=fs.readFileSync(p,'utf8');const original=s;for(const [oldtext,newtext] of rule){if(s.includes(newtext))continue;if(!s.includes(oldtext))throw Error(`${name}: required insertion point not found: ${oldtext.slice(0,75)}`);s=s.replace(oldtext,newtext);}if(s!==original)modifications[p]=s;}
rewrite('index.html',[[`<script src="/app.js" defer></script>`,`<script src="/paper-icons.js" defer></script><script src="/app.js" defer></script>`]]);
rewrite('combat.html',[[`<script src="/combat.js" defer></script>`,`<script src="/paper-icons.js" defer></script><script src="/combat.js" defer></script>`]]);
rewrite('app.js',[[`g.textContent=itemEmoji[kind]||'·';`,`g.textContent='';const paperImage=window.PaperIcons?.icon(kind);if(paperImage)g.append(paperImage);else g.textContent=itemEmoji[kind]||'·';`],[`h.textContent=title;p.textContent=description;el.append(h,p);`,`h.textContent=title;const paperItem=Object.entries(names).find(([k,label])=>title.startsWith(label));if(paperItem&&window.PaperIcons?.icon(paperItem[0]))h.prepend(window.PaperIcons.icon(paperItem[0]));p.textContent=description;el.append(h,p);`]]);
rewrite('world-ui.js',[[`button.textContent='🗺';`,`button.replaceChildren(window.PaperIcons?.icon('map')||document.createTextNode('🗺'));`],[`h.textContent=title;s.textContent=description;buttons.className='city-actions';`,`h.textContent=title;const paper=window.PaperIcons?.icon(kind);if(paper)h.prepend(paper);s.textContent=description;buttons.className='city-actions';`]]);
// Validate source content before applying edits.
for(const [f,c] of Object.entries(modifications)){if(f.endsWith('.js'))new Function(c);}
for(const [f,c] of Object.entries(modifications)){fs.writeFileSync(f,c);console.log('PATCHED '+path.relative(runtime,f));}
const assets=path.join(pub,'assets','paper-icons');fs.mkdirSync(assets,{recursive:true});
for(const name of ['paper_atlas_64_indexed.png','icons_registry.json','manifest.json']){fs.copyFileSync(path.join(here,'runtime','public','assets','paper-icons',name),path.join(assets,name));console.log('INSTALLED '+name);}for(const folder of ['icons_256','icons_64']){const dest=path.join(assets,folder);fs.mkdirSync(dest,{recursive:true});for(const name of fs.readdirSync(path.join(here,'runtime','public','assets','paper-icons',folder))){fs.copyFileSync(path.join(here,'runtime','public','assets','paper-icons',folder,name),path.join(dest,name));}}console.log('INSTALLED 20 canonical PNGs at 256px + 20 at 64px');
fs.copyFileSync(path.join(here,'runtime','public','paper-icons.js'),path.join(pub,'paper-icons.js'));
console.log('READY. Restart npm start and hard-reload the game. No gameplay, world or save files changed.');
